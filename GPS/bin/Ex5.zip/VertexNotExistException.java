//Name:Netanel Gabay
//I.D:303095228
//class that represents exception class which it's exception objects can be thrown by methods.
//this class refers to situations that junction is not exists
public class VertexNotExistException extends Exception{

	public VertexNotExistException(String msg){
		super(msg);
	}

}
