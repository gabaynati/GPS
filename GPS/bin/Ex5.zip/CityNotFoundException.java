//Name:Netanel Gabay
//I.D:303095228
//class that represents exception class which it's exception objects can be thrown by methods.
//this class refers to situations that city not exists
public class CityNotFoundException extends Exception {

public CityNotFoundException(String msg){
	super(msg);
}
}
